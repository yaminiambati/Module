package com.capgemini.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;


import org.springframework.stereotype.Repository;

import com.capgemini.model.HotelDetails;
@Transactional
@Repository("bookingDao")

public class BookingDAOImpl implements IBookingDAO {
	
	@PersistenceContext
	private EntityManager em; 
	@Override
	public List<HotelDetails> getHotel() {
		// TODO Auto-generated method stub
		List<HotelDetails> hotelDetails = em.createQuery("from HotelDetails").getResultList();
		/*for (HotelDetails hotelDetails2 : hotelDetails) {
			System.out.println(hotelDetails2);
		}*/
		return hotelDetails;
		
	}
	@Override
	public HotelDetails getHotelByName(String name) {
		// TODO Auto-generated method stub
		Query query = em.createQuery("from HotelDetails where name =:hname");
		query.setParameter("hname", name);
		List<HotelDetails> hotels = query.getResultList();
		return hotels.get(0);
	}

}
