package com.capgemini.dao;

import java.util.List;

import com.capgemini.model.HotelDetails;



public interface IBookingDAO {
	public List<HotelDetails> getHotel();
	public HotelDetails getHotelByName(String name);

}
