package com.capgemini.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.model.HotelDetails;
import com.capgemini.service.IBookingService;

@Controller
public class BookingController {
	
	@Autowired
	private IBookingService bookingService;
	/*private HotelDetails hotel;*/
	/*@RequestMapping("/HotelDetails")
	public String getHotel(ModelMap map) {
		List<HotelDetails> hotel = bookingService.getHotel();	
			map.put("hotels", hotel);
		return "HotelDetails";
	}
	*/
	@RequestMapping("/")
	public String showAllHotels(ModelMap map) {
		List<HotelDetails> hotels = bookingService.getHotel();
		map.put("hotels",  hotels);
		map.put("hotel", new HotelDetails());
		return "HotelDetails";
	}
	
	@RequestMapping("/booking/{name}")
	public String showBookingPage(@PathVariable("name") String name, ModelMap map) {
		HotelDetails hotel = bookingService.getHotelByName(name);
		map.put("hotel",  hotel);
		return "HotelBooking";
		
	}
	
	@RequestMapping("/booking/bookingDone/{name}")
	public ModelAndView showBookingPage(@PathVariable("name")String name) {
		return new ModelAndView("BookingConfirmation", "name", name);
	}

}
