package com.capgemini.service;

import java.util.List;

import com.capgemini.model.HotelDetails;

public interface IBookingService {
	public List<HotelDetails> getHotel();
	public HotelDetails getHotelByName(String name);
}
