package com.capgemini.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.IBookingDAO;
import com.capgemini.model.HotelDetails;
@Service("bookingService")
public class BookingServiceImpl implements IBookingService {
	@Autowired
	private IBookingDAO bookingDao;
	@Override
	public List<HotelDetails> getHotel() {
		// TODO Auto-generated method stub
		return bookingDao.getHotel();
	}
	@Override
	public HotelDetails getHotelByName(String name) {
		// TODO Auto-generated method stub
		return bookingDao.getHotelByName(name);
	}

}
